<option value="Open" {{$request->status=='Open'?'checked':''}}>Open</option>
<option value="Closed" {{$request->status=='Closed'?'checked':''}}>Closed</option>
<option value="Progress" {{$request->status=='Progress'?'checked':''}}>Progress</option>

