<footer class="footer">
    <div class="container-fluid text-center">
        <div class="row">
            <div class="col-sm-12">
                Copyright © <script>document.write(new Date().getFullYear())</script> | PayIT123 - FINFORTUNE INTERNATIONAL LIMITED (PayIT123).
            </div>
            <div class="mt-2">
                <p> <a href="https://payit123.com/privacy-policy.html" target="_blank">Privacy Policy</a> | <a href="https://payit123.com/terms-and-conditions.html" target="_blank">Terms of Use</a> | <a href="https://payit123.com/cookie-policy.html" target="_blank">Cookie Policy</a> | <a href="https://payit123.com/data-processing-policy.html" target="_blank">Data Processing Polic</a> </p>
            </div>
            <!-- <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                </div>
            </div> -->
        </div>
    </div>
</footer>